/*Crea un procedimiento almacenado que reciba dos parametros de entrada(nombre y edad) y los inserte en una tabla llamada personas
que tiene tres columnas (id, nombre, edad). El id es un valor autoincremental DA LA TABLA PERSONAS YA CREADA EN EL EXAMEN*/

/*Crea un procedimiento almacenado que reciba un parametro de entrada(id) y devuelva el nombre de la persona correspondiente de 
la tabla clientes*/

/*Crea una funcion que reciba un parametro de entrada que es el id del producto y devuelva el numero de unidades vendidas
de ese producto*/

/*Crea una funcion que reciba un parametro de entrada (id del producto) y devuelva el precio promedio de ese producto en
todos los pedidos*/

/*Crea un procedimiento almacenado con un cursor que recorra la tabla de productos y muestre por pantalla el nombre y el 
precio de cada producto*/

/*Crea un procedimiento almacenado que recorra los pedidos calcule el total de ventas de cada mes del año actual. El 
procedimiento debe devolver una tabla con dos columnas (mes y total)*/

/*Crea un cursor que recorra la tabla de productos y actualice el precio de cada producto un 10%*/








