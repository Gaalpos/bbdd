CREATE DEFINER=`root`@`localhost` PROCEDURE `Ejercicio04`()
BEGIN
select p.ProductName
from products p join orderdetails od using(ProductID) join orders o using(OrderID)
where month(OrderDate)=3;
END