/*Crea un procedimiento almacenado que muestre todos los productos en la tabla "products".*/
CREATE PROCEDURE `Ejercicio01` ()
BEGIN
select products
from products;
END
