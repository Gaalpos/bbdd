CREATE DEFINER=`root`@`localhost` PROCEDURE `Ejercicio05`()
BEGIN
select p.productName, e.FirstName
from products p join orderdetails od using(productID) join orders o using(orderID) join employees e using(employeeID)
where e.FirstName = 'Andrew';
END