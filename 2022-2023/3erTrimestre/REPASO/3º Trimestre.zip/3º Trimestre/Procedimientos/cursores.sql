set @maximo=0;
call cursor01(@maximo);
select @maximo;