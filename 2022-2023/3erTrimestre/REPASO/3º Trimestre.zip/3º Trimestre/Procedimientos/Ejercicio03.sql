CREATE DEFINER=`root`@`localhost` PROCEDURE `Ejercicio03`()
BEGIN
select count(ProductID)
from orderdetails;
END