CREATE DEFINER=`root`@`localhost` PROCEDURE `Ejercicio02`()
BEGIN
select CompanyName
from customers
where Region='Londres';
END