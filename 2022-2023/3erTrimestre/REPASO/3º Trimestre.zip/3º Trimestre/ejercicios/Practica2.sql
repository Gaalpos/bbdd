SELECT SUM(UnitsInStock) FROM products WHERE categoryID=1;

SHOW CREATE TABLE products;

SELECT DATA TYPE;