ALTER TABLE productos CHANGE descicion  descripcion VARCHAR(50); 
INSERT INTO productos (Descripcion, precio) VALUES ("Cable mod. Eloy", 5.23), ("Pañuelos Recamán",2.0),("Cases Eloy, 7.5")