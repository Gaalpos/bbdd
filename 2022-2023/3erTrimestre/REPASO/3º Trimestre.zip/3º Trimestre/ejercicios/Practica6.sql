SELECT UPPER(SUBSTRING(contactName,1,3))
FROM customers;