SELECT EJ3function("097-088")
SET GLOBAL log_bin_trust_function_creators = 1;