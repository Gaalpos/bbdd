CREATE TABLE IF NOT EXISTS productos(
	id INT auto_increment primary key,
    descripcion VARCHAR(50),
    precio DECIMAL(10,2));