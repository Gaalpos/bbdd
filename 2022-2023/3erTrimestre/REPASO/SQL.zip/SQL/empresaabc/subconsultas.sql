/*EJERCICIOS SUBCONSULTAS*/

/*3) Listar los vendedores que no trabajan en oficinas dirigidas por el empleado 108.*/
select *
from empleados 
where oficina in (select codOficina from directores where codDirector<>108);

/*4) Listar los productos (idfabricante, idproducto y descripción) para los cuales no se ha recibido
ningún pedido de 500 € o más.*/
select idProducto, idFabricante, descripcion
from productos
where idProducto in (select producto from lineaspedido group by producto
having sum(cantidad*precioVenta)<500);
/*SOLUCIÓN TENIENDO EN CUENTA QUE EL PRODUCTO NO APAREZCA EN NINGUNA
LÍNEA DE MÁS DE 500 EUROS*/
select idFabricante, idProducto, descripcion
from productos 
where idProducto not in (select distinct producto from lineaspedido
where (cantidad*precioVenta)>500);

/*5) Listar los clientes asignados a García Gómez, Luis Antonio que no han remitido un pedido
superior a 5.000 €.*/
select *
from clientes
where codRepresentante = 
(select codEmpleado
from empleados
where nombre='García Gómez, Luis Antonio') 
and codCliente in
(select distinct p.codCliente
from pedidos p join lineaspedido lp on p.codPedido=lp.codPedido
group by p.codCliente, p.codPedido having sum(cantidad*precioVenta) > 5000);

/*6) Listar las oficinas en donde haya un vendedor cuyas ventas representen más del 55% del objetivo
de su oficina.*/

/*7) Listar las oficinas en donde todos los vendedores tienen sueldos que superan al 50% del objetivo
de la oficina.*/

/*8,9) Listar las oficinas que tengan un objetivo mayor que la suma de los objetivos de sus vendedores.*/
SELECT o.codOficina,o.ciudad,o.objetivo
FROM oficinas o
WHERE o.objetivo > (SELECT SUM(objetivo) FROM empleados WHERE Oficina=o.codOficina);

/*10) Hallar cuántos pedidos (total de cada pedido) hay de más de 1800 €.*/
SELECT COUNT(p.codPedido)
FROM pedidos p 
WHERE (SELECT SUM(precioVenta*cantidad) FROM lineaspedido WHERE codPedido=p.codPedido)>1800;

/*11) Saber cuántas oficinas tienen empleados con ventas superiores a su objetivo, no queremos saber
cuáles sino cuántas hay.*/
SELECT codOficina,objetivo
FROM oficinas o
WHERE o.objetivo<
(SELECT SUM(lp.cantidad*lp.precioVenta) 
FROM empleados e 
JOIN pedidos p ON p.CodRepresentante=e.codEmpleado 
JOIN lineaspedido lp USING(codPedido) WHERE e.oficina=o.codOficina);

/*12) Listar las oficinas en donde todos los vendedores tienen ventas que superan al 50% del objetivo
de la oficina.*/
SELECT  e.oficina,SUM(lp.cantidad*lp.precioVenta)
FROM empleados e JOIN pedidos p ON e.codEmpleado=p.codRepresentante JOIN lineaspedido lp USING(codPedido)
GROUP BY e.oficina
HAVING SUM(lp.cantidad*lp.precioVenta)>(SELECT objetivo FROM oficinas WHERE codOficina=e.oficina)/2;

/*13) Seleccionar los pedidos, entendiendo por un pedido el Código del pedido y todas sus líneas, con
un importe superior a 30.000€.*/
SELECT p.codPedido PEDIDO,SUM(cantidad*precioVenta) TOTAL
FROM pedidos p JOIN lineaspedido USING(CodPedido)
WHERE codPedido<>21
GROUP BY p.codPedido
HAVING SUM(cantidad*precioVenta)>30000;

/*14) Listar las oficinas que no tienen director.*/
SELECT o.codOficina
FROM oficinas o
WHERE NOT EXISTS (SELECT * FROM directores WHERE codOficina=o.codOficina);

SELECT o.codOficina,d.idDirector
FROM oficinas o LEFT JOIN directores d USING(codOficina)
WHERE idDirector IS NULL;

/*15) Seleccionar los clientes que no han realizado ningún pedido.*/
SELECT c.codCliente,c.nombre
FROM clientes c
WHERE NOT EXISTS (SELECT * FROM pedidos WHERE codCliente=c.codCliente);

SELECT c.codCliente,c.nombre,p.codPedido
FROM pedidos p RIGHT JOIN clientes c USING(codCliente)
WHERE p.codPedido IS NULL;

/*16) Seleccionar los productos que no han sido vendidos.*/
SELECT p.idProducto,p.descripcion,p.existencias
FROM productos p
WHERE (SELECT COUNT(*) FROM lineaspedido WHERE Producto=p.idProducto)=0;

SELECT p.idProducto,p.descripcion
FROM productos p LEFT JOIN lineaspedido lp ON p.idProducto=lp.producto
WHERE lp.codPedido IS NULL;

/*17) Seleccionar los representantes que no han realizado ninguna venta, indicando el nombre del
empleado.*/
SELECT origen.codigo,origen.nombre
FROM (SELECT e.codEmpleado AS codigo,e.nombre AS nombre,p.codPedido AS pedido
FROM empleados e LEFT JOIN pedidos p ON p.codRepresentante=e.codEmpleado) AS origen
WHERE origen.pedido IS NULL;

SELECT * FROM (SELECT DISTINCT e.codEmpleado,e.nombre
FROM empleados e LEFT JOIN pedidos p ON e.codEmpleado=p.codRepresentante
WHERE p.codPedido IS NOT NULL) A ;
