select count(*) from 
(select codPedido, sum (cantidad*precioVenta)
from lineaspedido
group by codPedido
having sum (cantidad*precioVenta)>1800)