/*1*/
select first_name, last_name
from actor;
/*2*/
select *
from actor
where last_name like "%li%"
order by last_name, first_name;
/*3*/
select country, country_id
from country
where country in ("China", "Bangladesh","Afganistán");
/*4*/
select last_name, count(*)
from actor
group by last_name
having count(*)>=2;
/*5*/
select payment.staff_id, first_name, last_name, sum(amount)
from payment join staff using(staff_id)
where year(payment_date)=2005 and month(payment_date)=8
group by staff_id;
/*6*/
select film_id,title,count(*)
from film_actor join film using (film_id)
group by film_id;
/*7*/
select count(*)
from film join inventory using (film_id)
where title="Hunchback Impossible";
/*8*/
select c.category_id, c.name, sum(p.amount)
from  category c join film_category fc using (category_id) join inventory i using (film_id) join rental r using (inventory_id)
join payment p using (rental_id)
group by c.category_id
order by 3 desc limit 5;
/*9*/
select co.country, sum(p.amount)
from customer c join address a using(address_id) join city ci using(city_id) join country co using(country_id) 
join rental r using (customer_id) join payment p using (rental_id)
where co.country="UNITED STATES";
/*10*/
select *
from film f
where title like "Q%" or title like "K%" and language_id=(select language_id from language where name="English");


