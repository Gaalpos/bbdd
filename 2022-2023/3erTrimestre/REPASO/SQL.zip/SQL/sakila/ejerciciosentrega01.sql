/*1. Actores que tienen de primer nombre ‘Scarlett’.*/
select *
from actor
where first_name='Scarlett';

/*2. Actores que tienen de apellido ‘Johansson’.*/
select *
from actor
where last_name='Johansson';

/*3. Actores que contengan una ‘O’ en su nombre.*/
select *
from actor
where first_name like '%O%';

/*4. Actores que contengan dos ‘O’ en su nombre y en una ‘A’ en su apellido.*/
select *
from actor
where first_name like '%O%O%' and last_name like '%A%';

/*5. Listar las ciudades con nombres compuestos.*/
select city
from city
where city like "% %" or city like '%-%';

/*6. Listar las películas con una duración entre 80 y 100.*/
select *
from film
where length between 80 and 100;

/*7. Mostrar las ciudades del country Spain (consulta multitabla).*/
select ci.city
from city ci join country c using(country_id)
where c.country='Spain';

/*8. Mostrar el nombre de la película y el nombre de los actores que participan en ella.*/
select f.film_id, f.title, group_concat(concat(a.first_name,' ',a.last_name))as 'actores'
from film f join film_actor fa using(film_id) join actor a using(actor_id)
group by f.film_id
order by 1;

/*9. Mostrar el country, la ciudad y dirección de cada miembro del staff.*/
SELECT s.first_name,a.address,ci.city,co.country
FROM staff s JOIN address a USING(address_id) JOIN city ci USING(city_id) JOIN country co USING(country_id);

/*10. Mostrar el country, la ciudad y dirección de cada customer.*/
select c.country, ci.city, a.address, cu.first_name, cu.last_name
from country c join city ci join address a join customer cu;

/*11. Direcciones de california que tengan ‘274’ en el número de teléfono*/
select district, address, phone
from address
where district = 'california' and phone like '%274%';

/*12. Películas ‘Épicas’ (Epic) o ‘Brillantes’ (brilliant) que duren más de 180 minutos*/
select *
from film 
where length>180 and description like '%EPIC%' or description like '%BRILLIANT%';

/*13. Películas que duren entre 100 y 120 minutos o entre 50 y 70 minutos*/
/*SOLO ME COGE UNA PARTE LA OTRA NO*/
SELECT *
FROM film WHERE length BETWEEN 100 AND 120 OR length BETWEEN 50 AND 70;

/*14. Películas que cuesten 0.99, 2.99 y tengan un rating ‘g’ o ‘r’ y que hablen de cocodrilos
(cocodrile)*/
/*CONFIRMAR SI ESTA BIEN*/
SELECT *
FROM film WHERE rental_rate IN (0.99,2.99) AND description LIKE '%CROCODILE%' AND rating IN ('r','g');

/*15. Direcciones de Ontario o de Punjab o que su código postal acabe en 5 o que su teléfono
acabe en 5*/
select *
from address
where district = 'Ontario' or 'Punjab' or postal_code like '%5' or phone like '%5';

/*16. Alquileres con un pago por encima de la media*/
SELECT r.rental_id,p.amount
FROM rental r JOIN payment p USING(rental_id) WHERE p.amount > (SELECT AVG(p2.amount) FROM payment p2);

/*17. Actores que no han trabajado en películas con rating ‘R’*/
select first_name, last_name, rating
from actor join film
where rating not like '%R%';

/*18. Mostrar la categoría con menos películas*/
SELECT name,category_id,COUNT(*)
FROM film_category fc JOIN category c USING(category_id)
GROUP BY category_id
ORDER BY 3 ASC
LIMIT 1;

/*19. Películas en las que han trabajado más de 10 actores*/
SELECT film_id,title,COUNT(*)
FROM film_actor JOIN film USING(film_id)
GROUP BY film_id
HAVING COUNT(*)>10;

/*21. El título de la película que más se ha alquilado (en número de alquileres)*/

SELECT title ,max(rental_duration) as 'mas alquilada'
FROM film;

/*22. El título de la película que más dinero ha dado (en suma de importe)*/
/*CONFIRMAR SI ESTA BIEN*/
SELECT f.title
FROM rental r JOIN inventory i USING(inventory_id) JOIN film f USING(film_id)
GROUP BY f.film_id
ORDER BY COUNT(*) DESC 
LIMIT 1;

/*23. Los 5 actores que han trabajado en menos películas*/
SELECT a.first_name,a.last_name,COUNT(*)
FROM film_actor fa JOIN actor a USING(actor_id) 
GROUP BY fa.actor_id
ORDER BY 3 
LIMIT 5;

/*24. La referencia para los clientes es las dos primeras letras de su nombre y las dos primeras
letras de su apellido.*/

SELECT CONCAT(LEFT(first_name, 2), LEFT(last_name, 2)) AS referencia
FROM customer;

/*25. Hacer una consulta que nos muestre el id del cliente y esa referencia.*/

SELECT customer_id, CONCAT(LEFT(first_name, 2), LEFT(last_name, 2)) AS referencia
FROM customer;

/*26. Listar todos los pagos que se han hecho un viernes.*/

SELECT *
FROM payment
WHERE DAYOFWEEK(payment_date) = 6;

/*27. Clientes que no han alquilado documentales (‘documentary’)*/
SELECT * FROM customer WHERE customer_id NOT IN (
SELECT c.customer_id  
FROM customer c JOIN rental r USING(customer_id) JOIN inventory i USING(inventory_id) JOIN film f USING(film_id) JOIN film_category fc USING(film_id) JOIN category ca USING(category_id) WHERE
ca.name='Documentary');





 
