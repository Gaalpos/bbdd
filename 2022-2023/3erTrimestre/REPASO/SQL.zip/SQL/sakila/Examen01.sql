/*1. Muestra los nombres y apellidos de todos los actores de la tabla actor*/
select concat(first_name,' ', last_name) as Nombre
from actor;

/*2. Devuelve los actores cuyos apellidos contengan las letras li, ordenar las filas por apellido y nombre*/
select first_name, last_name
from actor
where last_name like '%li%'
order by last_name, first_name;

/*3. Con in, muestra las columnas country_id y country de los siguientes paises: afganistán, bangladesh y china*/
select country, country_id
from country
where country in('Afghanistán','Bangladesh','China');

/*4. Enumera los apellidos de los actores, la cantidad de actores que tienen ese apellido, pero solo para los nombres que comparten
al menos dos actores*/


/*5. Muestre el importe total cobrado por cada trabajador en el mes de agosto de 2005*/
select p.amount, s.first_name, p.payment_date
from payment p join staff s using(staff_id)
where month(p.payment_date) = 3 and year(curdate())-18;

/*6. Lista todas las peliculas y el numero de actores que aparecen en las peliculas*/
select distinct f.title, count( a.actor_id)
from actor a join film_actor fa using(actor_id) join film f using(film_id)
having count(fa.actor_id) ;

/*7. cuantas copias de la pelicula Hunchback Impossible existen en el inventario?*/
select count(*), f.title
from film f join inventory i using (film_id)
where f.title = 'Hunchback Impossible';

/*8. listar los cinco generos principales en ingresos en orden descendente*/
select c.name
from category c join film_category fc using(category_id) join film f using(film_id) join inventory i using(film_id) 
join rental r using (inventory_id) join payment p using(rental_id)
order by p.amount desc
limit 5;

/*9. Mostrar el importe pagado por aquellos clientes de estados unidos*/
select p.amount, c.first_name, co.country
from payment p join rental r using(rental_id) join customer c on(r.customer_id=c.customer_id) 
join country co on (c.customer_id = co.country_id)
where country = 'United States';

/*10. La música de Queen y Kris Kristoffernos ha visto un resurgimiento impensable. como consecuencia inesperada, las peliculas
que comienzan con las letras k y q tambien se han disparado en cuanto a alquileres. use subconsultas para mostrar los titulos de peliculas
que comienzan con las letras k y q cuyo idioma sea el ingles*/
select f.title
from film f join language l using(language_id)
where title like 'K%' or title like 'Q%' and l.name = (select name from language l where name = 'English');


