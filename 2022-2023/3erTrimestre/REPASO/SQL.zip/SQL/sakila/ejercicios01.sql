/*TABLA customer
- ¿Dónde vive 'JUDY GRAY'?
- ¿En cuántos países viven nuestros clientes? (países distintos)
- ¿Cuántos clientes viven en Egipto?
- ¿En qué ciudades de Egipto viven nuestros clientes?
- ¿Cuántos clientes viven fuera de Estados Unidos? (UNITED STATES)*/

#1
SELECT CONCAT(c.first_name," ",c.last_name) AS Nombre,ci.city AS Ciudad 
FROM customer c JOIN address a ON c.address_id=a.address_id JOIN city ci USING(city_id) 
WHERE first_name='JUDY' AND last_name='GRAY';

#2
SELECT COUNT(DISTINCT co.country_id) AS "PAÍSES CLIENTES"
FROM customer c JOIN address a USING(address_id) 
JOIN city ci USING(city_id) JOIN country co USING(country_id);

#3
SELECT COUNT(*) AS "Clientes egipcios"
FROM customer c JOIN address a USING(address_id) 
JOIN city ci USING(city_id) JOIN country co USING(country_id)
WHERE country='EGYPT';

#4
SELECT DISTINCT ci.city
FROM customer c JOIN address a USING(address_id) 
JOIN city ci USING(city_id) JOIN country co USING(country_id)
WHERE country='EGYPT';

#5
SELECT COUNT(*) AS "Clientes no americanos"
FROM customer c JOIN address a USING(address_id) JOIN city ci USING(city_id) JOIN country co USING(country_id)
WHERE co.country<>'UNITED STATES';

/*TABLA film
- Cuántas películas duran 90 o menos minutos?
- Cuántas películas van de astronautas?
- Lista todas las películas que duren como mucho 90 minutos y sean de astronautas.
- Lista los títulos de todas las películas, ordenadas por duración, de forma descendente.*/

#6 #avg
select count(*) from film where  length<=90;

#7
SELECT COUNT(*) FROM film f WHERE f.description LIKE 'ASTRONAUT';

#8
SELECT * FROM film f WHERE f.description LIKE 'ASTRONAUT' AND length<=90;

#9
SELECT title, length FROM film ORDER BY length DESC;

/*TABLAS Customer y Customer_list

- La tabla de clientes maneja el nombre y el apellido de los clientes en campos
separados, mientras que la tabla customer_list los almacena en un único campo.
Se desea usar la tabla de customer_list para obtener el nombre de los clientes, pero
queremos obtener la dirección de email y el estatus activo de los clientes de la tabla
de clientes.

- Haz una lista que muestre el customer_id, el nombre del cliente, la dirección de
correo electrónico y el estatus activo, ordenar la lista por el ID del cliente.

- Muestra una lista que contenga el ID de la ciudad, nombre de las ciudades y el
nombre de su país para aquellas ciudades donde haya clientes. Ordenar la lista por el
nombre del país.*/

#10
SELECT first_name,last_name FROM customer;

SELECT CONCAT(first_name,'.',last_name,"@cebem.es") AS correoE
FROM customer;

SELECT LOWER(CONCAT(SUBSTRING(first_name,1,1),last_name,"@cebem.es")),active FROM customer;

#11
SELECT customer_id,first_name,last_name,email,active FROM customer;

#12
SELECT DISTINCT ci.city_id,ci.city,co.country
FROM customer c JOIN address a USING(address_id) JOIN city ci USING(city_id) JOIN country co USING(country_id)