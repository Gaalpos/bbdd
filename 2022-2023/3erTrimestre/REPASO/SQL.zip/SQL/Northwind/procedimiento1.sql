set @total=0;
call TotalCliente('VINET', @total);

select @total;

SET GLOBAL log_bin_trust_function_creators = 1;

