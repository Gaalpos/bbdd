/*1.Obtén los nombres de los clientes que han hecho pedidos después del 1/1/98.*/

select CompanyName, OrderDate
from customers c join orders o using (CustomerID)
where year(OrderDate) between 1998 and curdate();

/*2.Obtén los nombres de los productos y de las compañías que los suministran. Los productos sin 
suministradores asignados y los suministradores sin productos asignados no se incluyen en el conjunto 
de resultados.*/

select p.ProductName, s.CompanyName
from products p join suppliers s using (SupplierID);

/*3.Realiza una consulta que permita presentar el número de la factura y el código
del cliente al cual ésta pertenece.*/



/*4.Realiza una consulta que muestre el listado de productos en el cual se incluya
el precio del producto, la diferencia entre el precio del producto y el precio
promedio de todos los productos.

El listado debe incluir las siguientes columnas: nombre del producto, precio
unitario, precio promedio de todos los productos, deferencia entre el precio
promedio y el precio del producto.*/

/*5.Realiza una consulta que muestre un listado de productos en el cual se incluya
el porcentaje que el producto representa para todo el inventario.

El listado debe incluir las siguientes columnas: nombre del producto, monto del
producto, monto total del inventario, porcentaje que representa el producto para
el inventario.*/

/*6.Realiza una consulta que muestre un listado donde se incluya los clientes que
han comprado productos de todas las categorías. Las columnas deberán ser:
código del cliente y nombre del cliente.*/

/*7.Realiza una consulta que muestre el listado de aquellos productos cuyo
promedio de unidades en pedidos sea mayor de 2.*/

/*8.Muestra el importe total que ha gastado cada cliente.*/

/*9.Realiza una consulta que muestre un listado de las Facturas de Cada Cliente.
El listado debe tener las siguientes columnas: Nombre del Cliente, País del
Cliente, No. de Factura, Fecha de Factura ordenado por Nombre del Cliente de
forma ascendente y luego por la fecha de la factura de forma descendente.*/

/*10.Realiza una consulta que muestre un listado de los empleados que le han
vendido a cada cliente. El listado debe tener las siguientes columnas: Nombre
del Cliente, Nombre completo del Empleado ordenado por Nombre del Cliente
de forma ascendente y luego por el Nombre completo del empleado de forma
ascendente.*/

/*11.Realiza una consulta que muestre un listado de los clientes y el número de
facturas de cada cliente. El listado debe tener las siguientes columnas: Código
Cliente, Nombre Cliente, total de facturas del Cliente.*/

/*12.Realiza una consulta que muestre un listado de los clientes y el monto total que
nos han comprado de los 5 clientes que más han comprado. El listado debe
tener las siguientes columnas: Código del Cliente, Nombre Cliente, Monto Total
gastado y ordenado por el Monto Total de forma descendente.*/

/*13.Realiza una consulta que muestre un listado de las ventas que se han hecho
por categoría. El listado debe tener las siguientes columnas: Nombre Categoría,
Monto Total y ordenado por el Monto Total de Forma ascendente.*/

/*14.Selecciona los datos de los productos con el nombre de la categoría a la que
pertenece.*/

/*15.Haz un listado que muestre el importe total de cada pedido.*/

/*16.Haz un listado que muestre el stock de cada producto y el número de unidades
vendidas.*/

/*17.Modifica el listado anterior para poder filtrar las ventas por mes y año.*/

/*18.Muestra un listado con las ventas totales que ha tenido cada cliente en cada
año.*/

/*19.Muestra un listado con las ventas totales de cada vendedor por año.*/

/*20.Muestra un listado con las ventas totales por vendedor y cliente en un año
determinado.*/

/*21.Muestra un resumen de las ventas totales por cliente y categoría de productos
en un año determinado.*/