/*1.Crea un procedimiento almacenado que muestre todos los productos en la tabla "products".*/

/*2.Crea un procedimiento almacenado que muestre todos los clientes en la tabla "customers" que tengan una dirección 
en la ciudad de "London".*/

/*3.Crea un procedimiento almacenado que muestre el número total de productos en la tabla "order details" para un pedido específico.*/

/*4.Crea un procedimiento almacenado que muestre el nombre del producto y la cantidad vendida para todos los productos 
vendidos en un mes específico.*/

/*5.Crea un procedimiento almacenado que muestre el nombre del producto y la cantidad vendida para todos los productos vendidos 
por un empleado específico.*/