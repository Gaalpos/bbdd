

USE aaaSegunda;
DROP DATABASE IF EXISTS aaaSegunda;

ALTER DATABASE aaaprimera DEFAULT COLLATE utf8mb4_bin;
alter database aaaprimera default collate latin1_bin;
alter database aaaprimera default collate latin1;

create table if not exists Alummos(
dni char (9),
nombre varchar (50),
fecNacimiento date,
curso enum ('1ºDAM','2ºDAM'),
nota int);

create table if not exists Modulos (
codigo int primary key,
nombre varchar (30) unique not null,
numHoras integer not null default 200,
nbProfesor varchar (50));

create table if not exists Coche(
matricula varchar (15),
marca varchar (20),
modelo varchar (20),
precio int not null,
primary key (matricula),
unique (marca));

create table if not exists Columnas (
clave1 int,
clave2 int,
nombre varchar (20),
primary key (clave1, clave2));

create table if not exists Muebles (
codigo int primary key,
linea varchar (20) not null,
color enum ('blanco','negro','beige'),
alto int not null,
ancho int not null,
largo int not null,
material varchar(20) not null,
altura int not null,
fabicrante varchar (50) not null,
foreign key (fabricante) references Fabricante (nbFabricante));

create table if not exists Muebles1(
codigo int primary key,
linea varchar (20) not null,
color enum ('blanco','negro','beige'),
alto int not null,
ancho int not null,
largo int not null,
material varchar(20) not null,
altura int not null,
fabicrante varchar (50) not null,
foreign key (fabricante) references Fabricante (nbFabricante));

create table if not exists Coche1(
matricula varchar (15),
marca varchar (20),
modelo varchar (20),
precio int not null,
constraint nbpkt primary key (matricula),
constraint nbuk unique (marca));

alter table Alumnos
add column direccion varchar(50);

