SELECT *
FROM empleados
WHERE fecContratos = (SELECT MIN (fechaPedido) FROM pedidos WHERE e.codEmpleado = codRepresentante);

SELECT codRepresentante, nombre
FROM lineaspedido JOIN pedidos USING (codPedido) JOIN empleados ON codRepresentante = codEmpleado
WHERE (cantidad*precioVenta) > 5000 OR objetivo < 200000
GROUP BY codRepresentante
ORDER BY 'pedidos','codRepresentante' ASC;