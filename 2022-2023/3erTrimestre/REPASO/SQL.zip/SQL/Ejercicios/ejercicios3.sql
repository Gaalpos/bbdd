/*7)Listar las ochos líneas del pedido más caras (las de mayor importe)*/

SELECT *
FROM Pedidos
WHERE MONTH (fechaPedido) = 3 AND YEAR (fechaPedido) = YEAR (CURDATE()) -1;

##año actual
SELECT *
FROM Pedidos
WHERE MONTH (fechaPedido) = 3 AND YEAR (fechaPedido) = YEAR (CURDATE());

/*8) Obtener las mismas columnas que en el ejercicio anterior pero sacando únicamente las 5 líneas
     de pedido de menor precio unitario*/
/*9) Listar toda la información de los pedidos de marzo del último año*/
/*10)*/
/*11)
*/
SELECT *
FROM Empleados;

SELECT codEmpleado, nombre
FROM Empleados
WHERE Oficina IS NOT NULL;

/*12) Listar los nombres de los empreados que no tienen asginada una oficina
*/
SELECT *
FROM Empleados
WHERE Oficinas IS NULL;

SELECT *
FROM Empleados
WHERE Oficinas <=> NULL;

/*13) Listar los datos de las oficinas 
*/
SELECT *
FROM Oficinas
WHERE Region = 'Galicia' OR 'Euskadi'
ORDER BY region;

##operador insert
SELECT *
FROM Oficinas
WHERE Region IN ('Galicia','Euskadi')
ORDER BY region DESC;

/*14) Listar los clientes de nombre Julia
*/
SELECT *
FROM Clientes
WHERE nombre LIKE 'Julia %';

/*15) Listar los productos cuyo idproducto acabe en x
*/
SELECT *
FROM Productos
WHERE idProducto LIKE '%x';

/*16) Obtener toda la información de los empleados cuya edad este comprendida entre
40 y 60 años
*/
SELECT codEmpleado, nombre, fecNacimiento, YEAR (CURDATE()) - YEAR (FecNacimiento) AS Edad
FROM Empleados
WHERE YEAR (CURDATE()) - YEAR (FecNacimiento) BETWEEN 40 AND 60;

## edad exacta
SELECT codEmpleado, nombre, fecNacimiento, YEAR (CURDATE()) - YEAR (FecNacimiento) -
IF (RIGHT(fecNacimiento, 5) > RIGHT(CURDATE(), 5), 1, 0) AS EDAD
FROM Empleados
WHERE YEAR (CURDATE()) - YEAR (FecNacimiento) -
IF (RIGHT(fecNacimiento, 5) > RIGHT(CURDATE(), 5), 1, 0) BETWEEN 40 AND 60;

/*17) Obtener todos los clientes cuyos representantes tengan los códigos 102,104 y 109
*/

SELECT *
FROM Clientes
WHERE codRepresentante = 102 OR codRepresentante = 104 OR codRepresentante = 109;

SELECT *
FROM Clientes
WHERE codRepresentante IN (102, 104, 109); 

/*18) Obtener un listado de todos los productos ordenados alfabéticamente por fabricante y después de
mayor a menor precio.
*/

SELECT *
FROM Productos
ORDER BY idFabricante, precioCompra DESC;

/*19) Listar todos los empleados que lleven trabajando más de 25 años en la empresa.
*/

SELECT codEmpleados, nombre, fechaContrato,
YEAR (CURDATE())-YEAR(fechaContrato) AS 'años trabajados';

/*20) Listar todas las oficinas que no tengan marcado ningún objetivo.
*/

SELECT *
FROM 

/*21) Obtener el nombre de todos los empleados cuyo salario acumulado hasta la fecha actual no han
llegado a cubrir el objetivo que tenían, además se deberá calcular el importe que les falta.
*/

SELECT ADDDATE(CURDATE(), INTERVAL 5 DAY), ADDDATE(CURDATE(), INTERVAL 5 MONTH),
ADDDATE(CURDATE(), INTERVAL 5 YEAR);

## sueldo anual
SELECT nombre, sueldo, sueldo * MONTH(CURDATE()) AS 'Sueldo Acumulado', objetivo
FROM Empleados
WHERE sueldo * MONTH (CURDATE()) < objetivo;

## sueldo acumulado desde que trabaja en la empresa
SELECT codNombre, sueldo, (YEAR (CURDATE()) - YEAR (FECContrato) - 1) * 12 * sueldo +
sueldo * MONTH (CURDATE()) AS 'Sueldo Acumulado'
FROM Empleados
WHERE (YEAR (CURDATE()) - YEAR (FECContrato) - 1) * 12 * sueldo +
sueldo * MONTH (CURDATE()) < objetivo AND (YEAR (CURDATE()) - YEAR (FECContrato) - 1) * 12 * sueldo +
sueldo * MONTH (CURDATE()) > 0;

SELECT codEmpleado, nombre, sueldo, IF (YEAR (FecContrato) <> YEAR (CURDATE()),
(YEAR (CURDATE()) - YEAR (FECContrato) - 1)*12*sueldo+
sueldo * MONTH(CURDATE()), sueldo * MONTH (CURDATE())) AS 'SUELDO ACUMULADO', objetivo
FROM Empleados
WHERE IF (YEAR (FecContrato) <> YEAR (CURDATE()),
(YEAR(CURDATE()) - YEAR (FECContrato)- 1)*12*sueldo+
sueldo * MONTH(CURDATE()), sueldo * MONTH (CURDATE())) < objetivo

/*22)*/

SELECT nombre, sueldo, comision, sueldo + comision AS sBruto, 
(sueldo + comision) * retencionesIRPF AS IRPF,
(sueldo + comision) * reetencionesSS AS SS,
(sueldo + comision) - (sueldo + comision) * retencionesIRPF - (sueldo + comision) * reetencionesSS
FROM Empleados;







