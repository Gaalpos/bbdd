SELECT * FROM aaaejemplo.alumnos;

##Producto cartesiano
SELECT *
FROM Cursos, 