SELECT SUM (lp.cantidad * lp.precioVenta) FROM pedidos p JOIN lineasPedido lp ON 
p.codPedido = lp.codPedido
WHERE p.codPedido = 1;

SELECT p.codigoPedido, p.fechaPedido, c.nombre, c.limiteCredito
FROM clientes c JOIN pedidos p ON c.codCliente = p.codCliente;

SELECT e.nombre, fecNacimiento, sueldo, categoria, fecContrato, o.region, o.region
FROM empleados e JOIN oficinas o ON e.Oficina = o.codOficina;

SELECT o.codOficina, o.ciudad, e.nombre
FROM oficinas o JOIN Directores d USING (CodOficina) JOIN empleados e ON d.codDirector = e.codEmpleado
WHERE o.objetivo > 3500;

/*7) Listar los empleados con un sueldo superior al de su jefe; para cada empleado sacar sus datos y el
número, nombre y sueldo de su jefe.*/

SELECT e.nombre AS pedido, e.nombre AS "Nombre empleado", c.nombre AS "Total linea"
FROM lineasPedido lp JOIN pedidos p USING (CodPedido) JOIN clientes c USING (codCliente)
JOIN empleados e ON c.codRepresentante = e.codEmpleado
WHERE (lp.cantidad*lp.precioVenta) > 150;

