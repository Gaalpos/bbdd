## listar el nombre del empleado, la oficina en al que trabaja indicando
## la ciudad y las ventas de la oficina
## JOIN

SELECT codEmpleado, nombre, oficina, cofoicina, ciuad, ventas
FROM Empleados JOIN oficinas ON oficinas = codoficina;

## producto cartesiano

SELECT codEmpleado, nombre, oficina, cofoicina, ciuad, ventas
FROM Empleados, Oficinas
WHERE oficina = codOficina;

## listar los pedidos indicando el nombre del cliente

## JOIN

SELECT codpedido, fecPedido, codCliente, nombre
FROM Pedidos JOIN Clientes USING (codCliente);

SELECT codpedido, fecPedido, clientes.codCliente, nombre
FROM Pedidos JOIN Clientes ON clientes.codClientes = pedidos.codClientes;

## producto cartesiano

SELECT codpedido, fecPedido, clientes.codCliente, nombre
FROM Pedidos, Clientes
WHERE clientes.codClientes = pedidos.codClientes;

## listar el codpedido, el producto (nombre), cantidad, precioVenta, importe
## JOIN

SELECT codPedido, descripcion, cantidad, precioVenta, cantidad * precioVenta
FROM LineasPedido JOIN Productos ON idFabricante = fabricante AND idProducto = producto;

## producto cartesiano

SELECT codPedido, descripcion, cantidad, precioVenta, cantidad * precioVenta
FROM LineasPedido, Productos
WHERE idFabricante = fabricante AND idProducto = producto;

## listar el codigo del pedido, codigo y nombre del cliente y el codigo y nombre del
## empleado que hizo la venta

## producto cartesiano
SELECT codPedido, fechaPedido,  codCliente, nombre, codEmpleado, nombre
FROM Clientes c, Pedidos p, Empleados e
WHERE c.codCliente = p.codCliente AND p.codRepresentante = codEmpleado;

## JOIN

SELECT p.codPedido, p.fechaPedido, c.codCliente, c.nombre, e.codEmpleado, e.nombre
FROM Clientes AS c JOIN Pedidos AS p USING (codCliente)
JOIN Empleados AS e ON codEmpleados = p.codRepresentante;

SELECT p.codPedido, p.fechaPedido, c.codCliente, c.nombre, e.codEmpleado, e.nombre
FROM Clientes c JOIN (Empleados e JOIN Pedidos p  ON codEmpleado = codRepresentante)
ON c.codCliente = p.codCliente;

## listar todos los clientes con su codPEdido y fecha del pedido

SELECT codCliente, nombre, codPedido, fechaPedido
FROM Clientes LEFT JOIN Pedidos USING (codCliente)
WHERE codPedido IS NULL;

## LISTAR LOS CLIENTES QUE NO HAN REALIZADO NINGUN PEDIDO

SELECT codCliente, nombre, codPedido, fechaPedido
FROM Pedidos LEFT JOIN CLientes USING (codCliente)
WHERE codPedido IS NULL;


## listar los productos que no se han vendido

SELECT idFabricante, fabricante, descripción, existencias, precioCompra, codPedido
FROM Productos LEFT JOIN LineasPedido 
ON idFabricante = fabricante AND idProducto = producto
WHERE codPedido IS NULL;

SELECT categoria
FROM Empleados
ORDER BY categoria;

