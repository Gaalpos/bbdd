##listar todos los clientes
SELECT * FROM Clientes;

SELECT codCliente. nombre, codfrepresentante, limititeCredito
FROM Clientes;

##listar el nombre y el sueldo de todos los empleados
SELECT nombre, sueldo
FROM Empleados;

##listar los datos del cliente incrementando 5000 el 
##limite de credito
SELECT nombre, limiteCredito, limiteCredito + 5000
FROM Clientes;

##mostrar la fecha de hoy 
SELECT now(), curdate();

##listar de la gtabla lineasPedido el fabricante, el pedido
##el producto, la cantidad, el precio y el importe

SELECT lp.codPedido as Pedido, producto, cantidad, precioVenta,
cantidad*precioVenta as Importe,
cantidad*precioVenta*0,21 as IVA,
cantidad*precioVenta*1,21 as Total
FROM bdempresasabc.lineasPedido as lp;

SELECT lp.codPedido as Pedido, producto, cantidad, precioVenta,
cantidad*precioVenta as Importe
FROM bdempresasabc.lineasPedido as lp;

##Calcular 2 elevado a la sexta, la raíz cuadrada de 25
##el resto de dividir 8 entre 3
SELECT pow(2,6) as portecia, sqrt(25) as 'raiz cuadrada',
MOD (8,3) as resto, 8%3 as resto1