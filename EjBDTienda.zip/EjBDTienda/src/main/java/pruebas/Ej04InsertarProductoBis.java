package pruebas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexion.Conexion;
import introducirDatos.IntroducirDatos;

public class Ej04InsertarProductoBis {

	public static void main(String[] args) {
		Conexion conexion = new Conexion();
		
		String sql = "INSERT INTO Productos (codigo, nombre, precio, codFabricante,"
				+ "existencias) VALUES (?, ?, ?, ?, ?)";
		
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(IntroducirDatos.introducirDatos("Codigo: ")));
			ps.setString(2,	 IntroducirDatos.introducirDatos("Nombre: "));
			ps.setDouble(3, Double.parseDouble(IntroducirDatos.introducirDatos("Precio:")));
			
			//buscar el codigo del fabricante, le pasamos el nombre
			int codFab = buscarCodigo(IntroducirDatos.introducirDatos("Nombre Fabricante: "));
			
			ps.setInt(4, codFab);
			ps.setInt(5, Integer.parseInt(IntroducirDatos.introducirDatos("Existencias: ")));
			
			if(ps.executeUpdate() != 0)
				System.out.println("Inserción OK");
			else
				System.out.println("Error al insertar");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conexion.desconectar();

	}

	private static int buscarCodigo(String nbFab) {
		Conexion conexion = new Conexion();
		
		String sql = "SELECT codigo FROM Fabricantes WHERE nombre = ?";
		int codigo = 0;
		
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sql);
			ps.setString(1, nbFab);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				codigo = rs.getInt("codigo");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conexion.desconectar();
		return codigo;
	}

}
