package pruebas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexion.Conexion;
import introducirDatos.IntroducirDatos;

public class Ej07ActualizarVentas {

	public static void main(String[] args) {
		/*7ª) A la hora de introducir los datos de la venta con código 20, 
		 * se produjo un error en la cantidad introducida. Valor 
		 * introducido 63 en lugar de 66.
		 */
		
		Conexion conexion = new Conexion();
		int codVenta = Integer.parseInt(IntroducirDatos.
				introducirDatos("Codigo Venta: "));
		int cantNueva = Integer.parseInt(IntroducirDatos.
				introducirDatos("Cantidad correcta: "));
		
		String sqlSelect = "SELECT codProducto, cantidad FROM Ventas "
				+ "WHERE codigo = ?";
		
		String sqlActVentas = "Update Ventas SET cantidad = ? "
				+ "WHERE codigo = ?";
		
		String sqlActProductos = "UPDATE Productos "
				+ "SET existencias = existencias + ? - ? "
				+ "WHERE codigo = ?";
		
		int codProducto = 0, cantAntigua = 0;
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sqlSelect);
			ps.setInt(1, codVenta);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				codProducto = rs.getInt("codProducto");
				cantAntigua = rs.getInt(2);
			}
			
			conexion.getConexion().setAutoCommit(false);
			ps = conexion.getConexion().prepareStatement(sqlActVentas);
			ps.setInt(1, cantNueva);
			ps.setInt(2, codVenta);
			
			ps.executeUpdate();
			
			ps = conexion.getConexion().prepareStatement(sqlActProductos);
			ps.setInt(1, cantAntigua);
			ps.setInt(2, cantNueva);
			ps.setInt(3, codProducto);
			
			ps.executeUpdate();
			
			conexion.getConexion().commit();
			System.out.println("Actualizacion OK");
				
		} catch (SQLException e) {
			try {
				conexion.getConexion().rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
				
		
	
		

	}

}
