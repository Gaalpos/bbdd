package pruebas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexion.Conexion;
import introducirDatos.IntroducirDatos;

public class Ej08Eliminar {

	public static void main(String[] args) {
		// 8ª) Eliminar la venta con código 1.
		
		Conexion conexion = new Conexion();
		
		String sqlEli =  "DELETE FROM Ventas WHERE codigo = ?";
		
		String sqlAct = "UPDATE Productos SET existencias = existencias + ? "
				+ "WHERE codigo = ?";
		
		String sqlSelect = "SELECT codProducto, cantidad FROM Ventas "
				+ "WHERE codigo = ?";
		
		int codVenta = Integer.parseInt(IntroducirDatos.introducirDatos
				("Codigo Venta: "));
		
		int codProducto = 0, cantidad = 0;
		
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sqlSelect);
			ps.setInt(1, codVenta);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				codProducto = rs.getInt("codProducto");
				cantidad = rs.getInt("cantidad");
			}
			//crear la transaccion
			conexion.getConexion().setAutoCommit(false);
			ps = conexion.getConexion().prepareStatement(sqlEli);
			ps.setInt(1, codVenta);
			
			ps.executeUpdate();
			
			ps = conexion.getConexion().prepareStatement(sqlAct);
			ps.setInt(1, cantidad);
			ps.setInt(2, codProducto);
			
			ps.executeUpdate();
			
			conexion.getConexion().commit();
			System.out.println("Eliminacion OK");
			
		conexion.desconectar();
		
		} catch (SQLException e) {
			try {
				conexion.getConexion().rollback();
			} catch (SQLException e1) {
				System.out.println("Error al eliminar");
			}
			e.printStackTrace();
		}
		
		
		
		

	}

}
