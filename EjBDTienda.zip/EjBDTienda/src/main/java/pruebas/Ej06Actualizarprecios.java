package pruebas;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import conexion.Conexion;
import introducirDatos.IntroducirDatos;

public class Ej06Actualizarprecios {

	public static void main(String[] args) {
		// 6ª) Se ha decidido incrementar el precio de la impresora 
		// Impresora HP Deskjet 3720 a 80 €.
		
		Conexion conexion = new Conexion();
		
		String sql = "Update Productos SET precio = ? "
				+ "WHERE codigo = ?";
		
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sql);
			ps.setDouble(1, Double.parseDouble(IntroducirDatos.introducirDatos("Precio: ")));
			ps.setInt(2, Integer.parseInt(IntroducirDatos.introducirDatos("Código: ")));
			
			if(ps.executeUpdate() != 0)
				System.out.println("Actualizacion OK");
			else
				System.out.println("Error al actualizar");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
