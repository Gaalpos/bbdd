package pruebas;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import conexion.Conexion;

public class Ej04InsertarProductos {

	public static void main(String[] args) {
		// 4ª) Compramos 3 portátiles ThinkBook 15 Gen 3 (15" AMD) 
		//al proveedor Lenovo código 2, el precio es de 916.75 €. 
		//Código asignado al producto 12.
		
		Conexion conexion = new Conexion();
		
		String sql = "INSERT INTO Productos (codigo, nombre, precio, codFabricante,"
				+ "existencias) VALUES (?, ?, ?, ?, ?)";
		
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sql);
			ps.setInt(1, 12);
			ps.setString(2, "ThinkBook 15 Gen 3 (15\" AMD)");
			ps.setDouble(3, 916.75);
			ps.setInt(4, 2);
			ps.setInt(5, 3);
			
			int fila  = ps.executeUpdate();
			if(fila != 0)
				System.out.println("Insercion OK");
			else
				System.out.println("Error al insertar");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conexion.desconectar();
		
	}

}
