package pruebas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexion.Conexion;

public class Ej09CrearVistas {

	public static void main(String[] args) {
	/*	9ª) Crear una vista para listar la cantidad y el importe total 
		vendido de cada producto, mostrando además el nombre del proveedor 
		y, el nombre del producto.
	*/
		Conexion conexion = new Conexion();
		 String sql = "CREATE VIEW viAgrupar2 AS  SELECT fabricantes.nombre AS fabri, productos.nombre AS produ, SUM(cantidad), "
		 		+ "FORMAT(SUM(cantidad*precio),2) " + 
		 		"FROM fabricantes JOIN Productos ON fabricantes.codigo = productos.codFabricante " + 
		 		"    JOIN Ventas ON ventas.codProducto = productos.codigo " + 
		 		"    GROUP BY fabricantes.nombre, productos.nombre";
		
		 try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sql);
			ps.execute();
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		conexion.desconectar();
		
		utilizarVista();

	}

	private static void utilizarVista() {
		// utilizar la vista viAgrupar
		
		Conexion conexion = new Conexion();
		
		String sql = "SELECT * FROM viAgrupar2";
		
		try {
			PreparedStatement ps = conexion.getConexion().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				System.out.println(rs.getString(1)+"\t"+
						rs.getString(2)+"\t"+
						rs.getString(3)+"\t"+
						rs.getString(4));
			}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conexion.desconectar();
		
	}

}
