package pruebas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import conexion.Conexion;

public class Ej03ListarCalculos {

	public static void main(String[] args) {
		/*3ª) Listar las ventas mostrando el nombre del producto, la cantidad, 
		 * el precio, el importe, el IVA (21%) y el total (importe +IVA).
		 */
		
		Conexion conexion = new Conexion();
		
		String sql = "SELECT nombre, cantidad, precio, cantidad*precio, "
				+ "(cantidad*precio)*0.21, (cantidad*precio)*1.21 "
				+ "FROM Productos JOIN Ventas ON productos.codigo = codProducto";
		
		PreparedStatement ps;
		try {
			ps = conexion.getConexion().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				System.out.println(rs.getString("nombre")+"\t"+
			rs.getInt("cantidad")+"\t"+rs.getDouble("precio")+"\t"+
						rs.getDouble(5)+"\t"+rs.getDouble(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		conexion.desconectar();

	}

}
