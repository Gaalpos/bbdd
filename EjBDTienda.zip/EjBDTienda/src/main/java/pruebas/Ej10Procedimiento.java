package pruebas;

import java.sql.CallableStatement;
import java.sql.SQLException;

import conexion.Conexion;
import introducirDatos.IntroducirDatos;

public class Ej10Procedimiento {

	public static void main(String[] args) {
		 /*10ª) Ejecutar un procedimiento que nos permita incrementar el 
		precio de los productos de un determinado fabricante. 
		El nombre del fabricante y el % de incremento se introducen 
		como parámetros.
		
	*/
		Conexion conexion = new Conexion();
		
		String sql = "{CALL prIncrementarPrecio(?, ?)}";
		
		try {
			CallableStatement cs = conexion.getConexion().prepareCall(sql);
			cs.setString(1, IntroducirDatos.introducirDatos("Fabricante: "));
			cs.setDouble(2, Double.parseDouble(IntroducirDatos.
					introducirDatos("Incremento: ")));
			if(!cs.execute())
				System.out.println("Incremento OK");
			else
				System.out.println("Fallo al ejecutar el procedimiento");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
