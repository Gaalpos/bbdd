package pruebas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import aaConvertirFechasDate.ConvertirFechas;
import conexion.Conexion;
import introducirDatos.IntroducirDatos;

public class Ej05InsertarVenta {

	public static void main(String[] args) {
		// 5ª) Realizamos una venta en el día de hoy de 
		// un portátil ThinkBook 15 Gen 3 (15" AMD).
		
		Conexion conexion = new Conexion();
		
		String sqlInsertar = "INSERT INTO Ventas (codProducto, cantidad, fecha) "
				+ "VALUES (?, ?, ?)";
		
		String sqlActualizar = "UPDATE Productos SET existencias = existencias - ? "
				+ "WHERE codigo = ?";
		int cantidad = 0;
		try {
			PreparedStatement psIns = conexion.getConexion().prepareStatement(sqlInsertar);
			PreparedStatement psAct = conexion.getConexion().prepareStatement(sqlActualizar);
			psIns.setInt(1, buscarCodProducto("GeForce GTX 1050Ti"));
			cantidad = Integer.parseInt(IntroducirDatos.introducirDatos("Cantidad: "));
			psIns.setInt(2, cantidad );
			String fecha = IntroducirDatos.introducirDatos("Fecha dd/mm/aaaa: ");
			Date fechaDate = ConvertirFechas.convertirStringDate(fecha);
			psIns.setDate(3, ConvertirFechas.convertirJavaDateASqlDate(fechaDate));
		
			psAct.setInt(2, buscarCodProducto("GeForce GTX 1050Ti"));
			psAct.setInt(1, cantidad);
			
			conexion.getConexion().setAutoCommit(false);
			psAct.executeUpdate();
			psIns.executeUpdate();
			conexion.getConexion().commit();
			conexion.getConexion().setAutoCommit(true);
			
		} catch (SQLException e) {
			
				try {
					conexion.getConexion().rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			e.printStackTrace();
		}
		
		conexion.desconectar();

	}

	private static int buscarCodProducto(String nbProducto) {
		Conexion conexion = new Conexion();
		String sql = "SELECT codigo FROM Productos WHERE nombre = ?";
		
		PreparedStatement ps;
		int codigo = 0;
		try {
			ps = conexion.getConexion().prepareStatement(sql);
			ps.setString(1, nbProducto);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next())
				codigo = rs.getInt("codigo");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		conexion.desconectar();
		return codigo;
	}

}
