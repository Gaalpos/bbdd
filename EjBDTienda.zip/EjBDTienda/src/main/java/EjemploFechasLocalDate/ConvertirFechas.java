package EjemploFechasLocalDate;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.swing.JOptionPane;

public class ConvertirFechas {

	// Covertir un tipo LocalDate en un String
	public static String convertirLocalDateString(LocalDate fec) {
		try {
			// Obtenemos solamente la fecha pero usamos slash en lugar de guiones
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/LLLL/yyyy");
			String formattedString = fec.format(formatter);
			return formattedString;
		} catch (NullPointerException np) {
			JOptionPane.showMessageDialog(null, "Sin fecha");
		}
		return null;
	}// fin convertirLocalDateString

	////////////////////////////////////////////////////////////////

	// Covertir un tipo String en un LocalDate
	public static LocalDate convertirStringLocalDate(String fecNac) {
		try {
			// convertir la fecha de un String a un tipo Date
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			
			// convert String to LocalDate
			LocalDate localDate = LocalDate.parse(fecNac, formatter);
			return localDate;
		} catch (Exception pe) {
			JOptionPane.showMessageDialog(null, "Error al introducir la fecha.", "Informaci�n",
					JOptionPane.INFORMATION_MESSAGE);
		}
		return null;
	}// fin convertirStringDate

	///////////////////////////////////////////////////////////////////////////////////////////////////

	// Cambia de java Date a SQL Date
	public static java.sql.Date convertirJavaLocalDateASqlDate(LocalDateTime dateTime) {
		java.sql.Date sqlDate = java.sql.Date.valueOf(dateTime.toLocalDate());
		return sqlDate;
	}
	
	//Recoger la fecha actual y convertirla en un String
	// Covertir un tipo LocalDate en un String
		public static String convertirFechaActualLocalDateString() {
			try {
				// Obtenemos solamente la fecha pero usamos slash en lugar de guiones
				LocalDate date = LocalDate.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/LLLL/yyyy");
				String formattedString = date.format(formatter);
				return formattedString;
			} catch (NullPointerException np) {
				JOptionPane.showMessageDialog(null, "Sin fecha");
			}
			return null;
		}// fin convertirLocalDateString

}
