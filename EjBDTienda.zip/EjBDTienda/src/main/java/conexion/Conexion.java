package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	static String bd = "BDTiendaInformatica";
	static String user = "root";
	static String password = "admin";
	
//	String url = "jdbc:mysql://localhost:3306/"+bd+
//			"?serverTimeZone=Europe/Madrid&useSSL=false";
	String url = "jdbc:mysql://localhost:3306/"+bd+
			"?serverTimeZone=Europe/Madrid&Public Key Retrieval=true";
	
	
	Connection conexion = null;
	
	public Conexion() {
		try {
			//obtener el driver para la conexion
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//crear la conexion
			conexion = DriverManager.getConnection(url, user, password);		
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException c) {
			c.printStackTrace();
		}
	}
	
	public Connection getConexion() {
		return conexion;
	}
	
	public void desconectar() {
		conexion = null;
	}

}
