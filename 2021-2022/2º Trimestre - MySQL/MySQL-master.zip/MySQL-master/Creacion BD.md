# Creación da Base de datos
## Proyecto investigación
![funcionando](IMG/basededatos/1.PNG)
![funcionando](IMG/basededatos/2.PNG)
![funcionando](IMG/basededatos/3.PNG)
![funcionando](IMG/basededatos/4.PNG)
![funcionando](IMG/basededatos/5.PNG)
![funcionando](IMG/basededatos/6.PNG)
![funcionando](IMG/basededatos/7.PNG)
![funcionando](IMG/basededatos/8.PNG)
![funcionando](IMG/basededatos/9.PNG)
![funcionando](IMG/basededatos/10.PNG)
![funcionando](IMG/basededatos/11.PNG)
![funcionando](IMG/basededatos/12.PNG)
![funcionando](IMG/basededatos/13.PNG)
![funcionando](IMG/basededatos/14.PNG)
![funcionando](IMG/basededatos/15.PNG)
![funcionando](IMG/basededatos/16.PNG)
![funcionando](IMG/basededatos/17.PNG)
![funcionando](IMG/basededatos/18.PNG)

## Show Proyecto investigación
![funcionando](IMG/basededatos/19.PNG)
## Naves Espaciales & Show
![funcionando](IMG/basededatos2/1.PNG)
![funcionando](IMG/basededatos2/2.PNG)
![funcionando](IMG/basededatos2/3.PNG)
![funcionando](IMG/basededatos2/4.PNG)
![funcionando](IMG/basededatos2/5.PNG)
![funcionando](IMG/basededatos2/6.PNG)
![funcionando](IMG/basededatos2/7.PNG)

# SHOW
![funcionando](IMG/show/1.PNG)
![funcionando](IMG/show/2.PNG)


PD: en algunas capturas da creacion das taboas non creei algun atributo, pero estan creados posterirormente para o correcto funcionamento da base de datos.
